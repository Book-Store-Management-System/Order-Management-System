import { Component, OnInit } from '@angular/core';
import { OrderModel } from '../model/OrderModel';
import { Router, ActivatedRoute } from '@angular/router';
import { NgserviceService } from '../ngservice.service';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {

  order= new OrderModel();
  constructor(private router: Router, private orderservice: NgserviceService,private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id= parseInt(this._activatedRoute.snapshot.paramMap.get('orderId'));
    this.orderservice.modifyOrder(id).subscribe(
      data=> {
        console.log("data received");
        this.order=data;
      },
      error=> console.log("error")
    )
  }
  updateOrderTosubmit()
  {
this.orderservice.addOrder(this.order).subscribe
(
  data =>
  {
    console.log("data added successfully");
    this.router.navigate(['']);
  },
  error=> console.log("error")
)
  }
  gotoList()
  {
    console.log("go back");
    this.router.navigate(['']);
  }

}
