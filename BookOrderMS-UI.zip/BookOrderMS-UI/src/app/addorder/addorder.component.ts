import { Component, OnInit } from '@angular/core';
import { OrderModel } from '../model/OrderModel';
import { Router } from '@angular/router';
import { NgserviceService } from '../ngservice.service';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {
  order= new OrderModel();
  constructor(private router: Router, private orderservice: NgserviceService ) { }

  ngOnInit(): void {

  }
  
  addOrderTosubmit()
  {
this.orderservice.addOrder(this.order).subscribe
(
  data =>
  {
    console.log("data added successfully");
    this.router.navigate(['']);

  },
  error=> console.log("error")
)
}
  gotoList()
  {
    console.log("go back");
    this.router.navigate(['']);
  }
  }

