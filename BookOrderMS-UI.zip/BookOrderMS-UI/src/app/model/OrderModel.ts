export class OrderModel {
    orderId:number;
    orderBy:string;
    paymentMethod:string;
    orderDate:Date;
    orderbookcopies:number;
    totalAmount:number;
    orderStatus:string;
    bookRate:number
}
   