import { Component, OnInit } from '@angular/core';
import { OrderModel } from '../model/OrderModel';
import { NgserviceService } from '../ngservice.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrls: ['./vieworder.component.css']
})
export class VieworderComponent implements OnInit {
order= new OrderModel();
  constructor(private _service: NgserviceService , private router: Router,private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id= parseInt(this._activatedRoute.snapshot.paramMap.get('orderId'));
    this._service.viewOrderById(id).subscribe(
      data=> {
        console.log("data received");
        this.order=data;
      },
      error=> console.log("error")
    )
  }
  gotoList()
  {
    console.log("go back");
    this.router.navigate(['']);
  }
}
