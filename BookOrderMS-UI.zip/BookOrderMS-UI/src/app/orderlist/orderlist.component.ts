import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
import {OrderModel} from '../model/OrderModel'
import { Router } from "@angular/router";
import { from } from 'rxjs';

@Component({
  selector: 'app-orderlist',
  templateUrl: './orderlist.component.html',
  styleUrls: ['./orderlist.component.css']
})
export class OrderlistComponent implements OnInit {
_order=[OrderModel];
constructor(private _service: NgserviceService , private router: Router) { }

ngOnInit(): void {
  this._service.ViewAllOrder().subscribe(
    data=> {console.log("response received");
    this._order=data;
  },
    error=> console.log("exception occurred")
  )
}
goToAddOrder(){
  this.router.navigate(['/addOrder']);

}

goToEditOrder(orderId: number)
{
  console.log("Order Id"+orderId);
  this.router.navigate(['/editOrder',orderId]);

}
goToviewOrder(orderId:number)
{
  console.log("Order Id"+orderId);
  this.router.navigate(['/viewOrder',orderId]);
}
deleteOrder(orderId:number){
  alert('Order Deleted!!!!');
  this._service.removeOrder(orderId).subscribe(
    data => {
    console.debug("deleted successfully");
    this.router.navigate(['']);

    },
error => console.log("exception occurred")
  )
}
}