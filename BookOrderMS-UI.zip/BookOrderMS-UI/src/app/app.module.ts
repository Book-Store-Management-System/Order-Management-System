import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddorderComponent } from './addorder/addorder.component';
import { OrderlistComponent } from './orderlist/orderlist.component';
import { EditorderComponent } from './editorder/editorder.component';
import { VieworderComponent } from './vieworder/vieworder.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AddorderComponent,
    OrderlistComponent,
    EditorderComponent,
    VieworderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
