import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderlistComponent } from './orderlist/orderlist.component';
import { AddorderComponent } from './addorder/addorder.component';
import { EditorderComponent } from './editorder/editorder.component';
import { VieworderComponent } from './vieworder/vieworder.component';

// import { AddorderComponent } from './addorder/addorder.component';
// import { EditorderComponent } from './editorder/editOrder.component';
// import { VieworderComponent } from './vieworder/viewOrder.component';
// import { OrderlistComponent } from './orderlist/orderlist.component';

const routes: Routes = [
  {path:'',component:OrderlistComponent},
  {path:'addOrder',component:AddorderComponent},
  {path:'editOrder/:orderId',component:EditorderComponent},
  {path:'editOrder',component:EditorderComponent},
  {path:'viewOrder/:orderId',component:VieworderComponent},
  {path:'viewOrder',component:VieworderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
