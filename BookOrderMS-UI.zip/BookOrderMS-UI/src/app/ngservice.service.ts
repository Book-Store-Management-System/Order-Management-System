import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { OrderModel } from './model/OrderModel';
@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

  constructor(private _http:HttpClient) { }

  ViewAllOrder():Observable<any>{
    return this._http.get<any>(" http://localhost:9090//Order/viewAllOrder");
  }
  addOrder(order: OrderModel): Observable<Object> {
    return this._http.post<any>(" http://localhost:9090/Order/addOrder", order);
  }
  modifyOrder(orderId: number): Observable<any>
  {
    return this._http.get<any> ("http://localhost:9090/Order/updateOrderById/"+orderId );
  }
  removeOrder(orderId: number): Observable<any>
  {
    return this._http.delete<any> ("http://localhost:9090/Order/deleteOrder/"+orderId );
  }
  viewOrderById(orderId: number): Observable<any>
  {
    return this._http.get<any> ("http://localhost:9090/Order/viewAllOrder/"+orderId );
  }
}
